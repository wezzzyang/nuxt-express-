export default function({$axios,redirect}){
    $axios.onRequest(config=>{
        console.log("Making request to"+config.url)
        //从本地获取token
       let token = localStorage.getItem("token")
       //如果token不为空，将token放入请求中
       if(token){
           config.headers.authorization = token
       }
       return config
    })
//错误处理机制
    $axios.onError(error => {
       const code = parseInt(error.response&&error.response.status)
       if(code===400){
           redirect('/400')
       }
    })
}