
export const actions = {
    registerAxios: function(state,registerData) {
    console.log('state: ', state);
        return this.$axios.post(`user/register`,registerData);
    }
}